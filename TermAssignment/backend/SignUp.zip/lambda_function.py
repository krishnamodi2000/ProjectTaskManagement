import boto3
import uuid
import hashlib
import json

dynamodb = boto3.resource('dynamodb')
user_table = dynamodb.Table('Usersdb')
sns_client = boto3.client('sns')


def lambda_handler(event, context):
    body_json=event.get('body')
    event=json.loads(body_json)
    email = event.get('email')
    employee_id = event.get('employee_id')
    password = event.get('password')
    confirm_password = event.get('confirm_password')
 
    # Check if email and employee_id are both missing
    if not email and not employee_id:
        return {
            'statusCode': 400,
            'body': 'Please provide either the email or employee_id.'
        }

    # Validate passwords match
    if password != confirm_password:
        return {
            'statusCode': 400,
            'body': 'Passwords do not match.'
        }

    hashed_password=hashlib.sha256(password.encode('utf-8')).hexdigest()
    print(hashed_password)

    # Check if the provided email or employee ID already exists in DynamoDB
    response = user_table.scan(
        FilterExpression='Email = :email OR EmployeeId = :employee_id',
        ExpressionAttributeValues={':email': email, ':employee_id': employee_id}
    )

    if response['Count'] > 0:
        return {
            'statusCode': 409,
            'body': 'User already signed up.'
        }

    # Generate a unique user ID
    user_id = str(uuid.uuid4())

    # Store user information in DynamoDB (without confirmed status initially)
    user_table.put_item(
        Item={
            'UserId': user_id,
            'Email': email,
            'EmployeeId': employee_id,
            'Password': hashed_password
        }
    )
    


    return {
        'statusCode': 200,
        'body': 'User signup successful.'
    }
