import boto3
import json

dynamodb = boto3.resource('dynamodb')
tasks_table = dynamodb.Table('Tasks')  # Replace with your DynamoDB table name for tasks

def lambda_handler(event, context):
    body_json=event.get('body')
    event=json.loads(body_json)
    project_id = event.get('project_id')

    # Check if project_id is missing in the request
    if not project_id:
        return {
            'statusCode': 400,
            'body': 'Please provide the project_id.'
        }

    # Get all tasks for the specified project_id from the DynamoDB table
    response = tasks_table.scan(
        FilterExpression='ProjectId = :project_id',
        ExpressionAttributeValues={':project_id': project_id}
    )

    tasks = response['Items']

    return {
        'statusCode': 200,
        'body': json.dumps(tasks)
    }
