import boto3
import json

dynamodb = boto3.resource('dynamodb')
projects_table = dynamodb.Table('Projects')

def lambda_handler(event, context):
    response = projects_table.scan()
    projects = response['Items']
    return {
        'statusCode': 200,
        'body': json.dumps(projects)
    }
