import boto3
import uuid
import hashlib
import json

dynamodb = boto3.resource('dynamodb')
user_table = dynamodb.Table('Usersdb')
sns_client = boto3.client('sns')

def lambda_handler(event, context):
    body_json=event.get('body')
    event=json.loads(body_json)
    email_or_employee_id = event['email_or_employee_id']
    password = event['password']

    # Check if the provided email/employee ID exists in DynamoDB
    response = user_table.scan(FilterExpression='Email = :email OR EmployeeId = :employee_id',
                               ExpressionAttributeValues={':email': email_or_employee_id, ':employee_id': email_or_employee_id})

    if response['Count'] != 1:
        return {
            'statusCode': 404,
            'body': 'User not found.'
        }
    
    user = response['Items'][0]
    print(user)
        
    # Compare the entered password with the stored password   
    hashed_password=hashlib.sha256(password.encode('utf-8')).hexdigest()
    print(hashed_password)

    if user['Password'] != hashed_password:
        return {
            'statusCode': 401,
            'body': 'Invalid password.'
        }
    

    
    return {
        'statusCode': 200,
        'body': 'User Logged In.'
    }
