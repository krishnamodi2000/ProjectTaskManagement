import boto3
import json 

dynamodb = boto3.resource('dynamodb')
user_table = dynamodb.Table('Usersdb')  # Replace with your DynamoDB table name

def lambda_handler(event, context):
    body_json=event.get('body')
    event=json.loads(body_json)
    email_or_employee_id = event.get('email_or_employee_id')

    # Check if email and employee_id are both missing
    if not email_or_employee_id:
        return {
            'statusCode': 400,
            'body': 'Please provide either the email or employee_id.'
        }

    # Check if the provided email or employee ID exists in DynamoDB
    response = user_table.scan(
        FilterExpression='Email = :email OR EmployeeId = :employee_id',
        ExpressionAttributeValues={':email': email_or_employee_id, ':employee_id': email_or_employee_id}
    )

    if response['Count'] == 0:
        return {
            'statusCode': 404,
            'body': 'User not found.'
        }

    user_details = response['Items'][0]

    # Remove sensitive information from the user details if needed (e.g., password)
    if 'Password' in user_details:
        del user_details['Password']
    
    print(user_details)

    return {
        'statusCode': 200,
        'body': json.dumps(user_details)
    }
