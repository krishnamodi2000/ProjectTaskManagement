import boto3
import json

dynamodb = boto3.resource('dynamodb')
requests_table = dynamodb.Table('Requests')  # Replace with your DynamoDB table name
user_table = dynamodb.Table('Usersdb')  # Replace with your DynamoDB table for projects
sqs_client = boto3.client('sqs')
sns_client=boto3.client('sns')
queue_url = boto3.resource('sqs').get_queue_by_name(QueueName='AdminRequestsQueue').url

def lambda_handler(event, context):
    # Receive messages from the SQS queue
    response = sqs_client.receive_message(QueueUrl=queue_url, MaxNumberOfMessages=1)

    if 'Messages' in response:
        # Assuming the SQS message body contains the request details as a JSON string
        message_body = response['Messages'][0]['Body']
        sqs_message = json.loads(message_body)

        request_id = sqs_message['request_id']
        email = sqs_message['email']
        project_id = sqs_message['project_id']

        # Process the project access request (e.g., update the status in the database)
        # For simplicity, let's assume we just want to approve the request
        requests_table.update_item(
            Key={'request_id': request_id},
            UpdateExpression='SET #s = :status',
            ExpressionAttributeValues={':status': 'Approved'},
            ExpressionAttributeNames={'#s': 'status'}
        )
        
        userfound = user_table.scan(
        FilterExpression='Email = :email',
        ExpressionAttributeValues={':email': email}
        )
        
        userid=userfound['Items'][0]['UserId']

        # Update user access in the Projects table (Add user to the Users list)
        userapproval = user_table.get_item(Key={'UserId': userid})
        print(userapproval)
        if 'Item' in userapproval:
            print("reached here")
            # User record exists, check if 'Projects' attribute exists
            if 'Projects' in userapproval['Item']:
                # Append project to the existing list
                user_table.update_item(
                    Key={'UserId': userid},
                    UpdateExpression='SET Projects = list_append(Projects, :project)',
                    ExpressionAttributeValues={':project': [project_id]}
                )
            else:
                # Create a new 'Projects' attribute with the current project
                user_table.update_item(
                    Key={'UserId': userid},
                    UpdateExpression='SET Projects = :project_list',
                    ExpressionAttributeValues={':project_list': [project_id]}
                )
                
        print(project_id)
        topics = sns_client.list_topics()
        topic_arn = next((topic['TopicArn'] for topic in topics['Topics'] if project_id in topic['TopicArn']), None)
        
        print(topic_arn)
        # Subscribe to the SNS Topic
        sns_client.subscribe(
        TopicArn=topic_arn,
        Protocol='email',
        Endpoint=email
        )
    
        # Delete the processed message from the SQS queue
        receipt_handle = response['Messages'][0]['ReceiptHandle']
        sqs_client.delete_message(QueueUrl=queue_url, ReceiptHandle=receipt_handle)

    return {
        'statusCode': 200,
        'body': 'Project access request processed.'
    }
