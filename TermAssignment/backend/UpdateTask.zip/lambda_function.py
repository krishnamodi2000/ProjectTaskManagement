import boto3
import json

dynamodb = boto3.resource('dynamodb')
tasks_table = dynamodb.Table('Tasks')
projects_table=dynamodb.Table('Projects')
sns_client = boto3.client('sns')

def lambda_handler(event, context):
    body_json=event.get('body')
    event=json.loads(body_json)
    task_id = event['task_id']
    new_status = event['new_status']

    # Update the task status in the Tasks table
    tasks_table.update_item(
        Key={'TaskId': task_id},
        UpdateExpression='SET TaskStatus = :status',
        ExpressionAttributeValues={':status': new_status}
    )
    
    task_available = tasks_table.get_item(Key={'TaskId': task_id})
    project_id=task_available['Item']['ProjectId']
    project_available = projects_table.get_item(Key={'project_id': project_id})
    task_name = task_available['Item']['TaskName'] 
    project_name= project_available['Item']['project_name']
    print(project_id)
    topics = sns_client.list_topics()
    topic_arn = next((topic['TopicArn'] for topic in topics['Topics'] if project_id in topic['TopicArn']), None)

    print(topic_arn)
    creation_message = f'Task Updated: \n Task Name: {task_name} \n Task Status: {new_status}'
    print(creation_message)
    sns_client.publish(
        TopicArn=topic_arn,
        Message=creation_message,
        Subject=f'A Task is updated: {task_name} in {project_name}'
    )

    return {
        'statusCode': 200,
        'body': 'Task status updated.'
    }
