import boto3
import json
import uuid

dynamodb = boto3.resource('dynamodb')
requests_table = dynamodb.Table('Requests')
sqs_client = boto3.client('sqs')
queue_url = boto3.resource('sqs').get_queue_by_name(QueueName='AdminRequestsQueue').url

def lambda_handler(event, context):
    body_json=event.get('body')
    event=json.loads(body_json)
    email = event['email']
    project_id = event['project_id']
    
    # Generate a unique request ID
    request_id = str(uuid.uuid4())

    # Store the request in DynamoDB
    requests_table.put_item(Item={
        'request_id': request_id,
        'email': email,
        'project_id': project_id,
        'status': 'Pending'  # Set an initial status for the request (e.g., Pending)
    })

    # Send the request details to the SQS queue
    sqs_message = {'request_id': request_id, 'email': email, 'project_id': project_id}
    sqs_client.send_message(QueueUrl=queue_url, MessageBody=json.dumps(sqs_message))

    return {
        'statusCode': 200,
        'body': 'Project access request sent. Waiting for approval.'
    }