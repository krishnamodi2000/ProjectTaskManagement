import boto3
import uuid
import json

dynamodb = boto3.resource('dynamodb')
sns_client = boto3.client('sns')
tasks_table = dynamodb.Table('Tasks')
projects_table = dynamodb.Table('Projects')


def lambda_handler(event, context):
    body_json=event.get('body')
    event=json.loads(body_json)
    project_id = event['project_id']
    task_name = event['task_name']
    task_description = event['task_description']

    # Generate a unique task ID
    task_id = str(uuid.uuid4())

    # Store the task in the Tasks table
    tasks_table.put_item(Item={
        'TaskId': task_id,
        'ProjectId': project_id,
        'TaskName': task_name,
        'TaskDescription': task_description,
        'TaskStatus': 'To do'
    })

    project_available = projects_table.get_item(Key={'project_id': project_id})
    project_name = project_available['Item']['project_name']
    print(project_id)
    topics = sns_client.list_topics()
    topic_arn = next((topic['TopicArn'] for topic in topics['Topics'] if project_id in topic['TopicArn']), None)

    print(topic_arn)
    creation_message = f'Task created: \n Task Name: {task_name} \n Task Description: {task_description}'
    print(creation_message)
    sns_client.publish(
        TopicArn=topic_arn,
        Message=creation_message,
        Subject=f'A new Task is created in project {project_name}'
    )

    return {
        'statusCode': 200,
        'body': 'Task created successfully.'
    }
