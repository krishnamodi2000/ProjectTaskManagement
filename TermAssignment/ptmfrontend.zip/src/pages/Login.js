import React, { useState } from 'react';
import { Button, Container, TextField, Typography } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';


function Login() {
  const [emailOrEmployeeId, setEmailOrEmployeeId] = useState('');
  const [password, setPassword] = useState('');
  const LoginEndpoint=`${process.env.REACT_APP_API_ENDPOINT}/login`
  console.log(LoginEndpoint)

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Email or Employee ID validation
    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
    const empIdRegex = /^[A-Za-z]{3}\d{6}$/;
    if (!emailRegex.test(emailOrEmployeeId) && !empIdRegex.test(emailOrEmployeeId)) {
      alert('Invalid Email or Employee ID. Please enter a valid email or a 3-character Employee ID followed by 6 digits.');
      return;
    }

    // Password validation
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordRegex.test(password)) {
      alert(
        'Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character (@ $ ! % * ? &).'
      );
      return;
    }

    try {
      const response = await fetch(LoginEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email_or_employee_id: emailOrEmployeeId,
          password: password,
        }),
      });

      if (response.ok) {
        // Handle successful login
        navigate(`/dashboard/${emailOrEmployeeId}`);
      } else {
        // Handle login error
        const errorData = await response.json();
        console.log('Login error:', errorData);
      }
    } catch (error) {
      // Handle other errors
      console.error('Error occurred:', error);
    }
  };

  return (
    <>
    <Container maxWidth="sm">
      <Typography variant="h4" component="h1" gutterBottom>
        Login
      </Typography>
      <form onSubmit={handleSubmit}>
        <TextField
          label="Email or Employee ID"
          type="text"
          value={emailOrEmployeeId}
          onChange={(e) => setEmailOrEmployeeId(e.target.value)}
          fullWidth
          margin="normal"
          required
        />
        <TextField
          label="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          fullWidth
          margin="normal"
          required
        />
        <Button variant="contained" color="primary" type="submit">
          Login
        </Button>
        <Typography variant="body2" gutterBottom>
          Don't have an account? <Link to="/">Sign Up</Link>
        </Typography>
      </form>
    </Container>
  </>

  );
}

export default Login;
