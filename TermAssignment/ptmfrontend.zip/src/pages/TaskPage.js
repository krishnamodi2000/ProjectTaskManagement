import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Container, Typography, Grid, Card, CardContent, Button, Menu, MenuItem, Dialog, DialogTitle, DialogContent, DialogActions, TextField,} from '@mui/material';
import Footer from '../components/Footer';
import Navbar from '../components/Navbar';

const statusOptions = {
  'To do': ['In Progress', 'In Review', 'Done'],
  'In Progress': ['To do', 'In Review', 'Done'],
  'In Review': ['To do', 'In Progress', 'Done'],
  Done: ['To do', 'In Progress', 'In Review'],
};


function TaskPage() {
  const location = useLocation();
  const projectID = location.pathname.split('/tasks/')[1];
  const [tasks, setTasks] = useState([]);
  const [anchorEl, setAnchorEl] = useState(null);
  const [selectedTaskId, setSelectedTaskId] = useState(null);
  const ShowTasksEndpoint=`${process.env.REACT_APP_API_ENDPOINT}/tasks`
  console.log(ShowTasksEndpoint)
  const CreateTaskEndpoint=`${process.env.REACT_APP_API_ENDPOINT}/createtask`
  console.log(CreateTaskEndpoint)
  const UpdateTaskEndpoint=`${process.env.REACT_APP_API_ENDPOINT}/updatetask`
  console.log(UpdateTaskEndpoint)

  useEffect(() => {
    if (projectID) {
      const fetchTasksData = async () => {
        try {
          const response = await fetch(
            ShowTasksEndpoint,
            {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                project_id: projectID,
              }),
            }
          );

          if (response.ok) {
            const responseData = await response.json();
            setTasks(responseData);
          } else {
            console.log('Failed to fetch tasks data:', response.status);
          }
        } catch (error) {
          console.error('Error occurred while fetching tasks data:', error);
        }
      };

      fetchTasksData();
    }
  }, [projectID]);

  const handleUpdateStatus = async (taskId, newStatus) => {
    try {
      // Send a POST request to the backend API to update the task status
      const response = await fetch(
        UpdateTaskEndpoint,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            task_id: taskId,
            new_status: newStatus,
          }),
        }
      );

      if (response.ok) {
        // Update the task status in the local state if the backend request is successful
        setTasks((prevTasks) =>
          prevTasks.map((task) => (task.TaskId === taskId ? { ...task, TaskStatus: newStatus } : task))
        );
        console.log('Task status updated successfully.');
      } else {
        console.log('Failed to update task status:', response.status);
        // Optionally, you can show an error message to the user using a toast or any other UI component.
      }
    } catch (error) {
      console.error('Error occurred while updating task status:', error);
      // Optionally, you can show an error message to the user using a toast or any other UI component.
    } finally {
      setAnchorEl(null);
      setSelectedTaskId(null);
    }
  };

  const handleUpdateButtonClick = (event, taskId) => {
    setAnchorEl(event.currentTarget);
    setSelectedTaskId(taskId);
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
    setSelectedTaskId(null);
  };

  const renderUpdateMenu = (taskId, status) => {
    return (
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl) && selectedTaskId === taskId}
        onClose={handleCloseMenu}
      >
        {statusOptions[status].map((option) => (
          <MenuItem key={option} onClick={() => handleUpdateStatus(taskId, option)}>
            Move to {option}
          </MenuItem>
        ))}
      </Menu>
    );
  };

  // Modal state
  const [openModal, setOpenModal] = useState(false);
  const [modalData, setModalData] = useState({
    project_id: '',
    task_name: '',
    task_description: '',
  });

  const handleModalOpen = () => {
    setOpenModal(true);
  };

  const handleModalClose = () => {
    setOpenModal(false);
  };

  const handleModalInputChange = (e) => {
    const { name, value } = e.target;
    setModalData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleCreateTask = async () => {
    try {
      const response = await fetch(
        CreateTaskEndpoint,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(modalData),
        }
      );

      if (response.ok) {
        const responseData = await response.json();
        console.log(responseData.body);
        // Optionally, you can show a success message to the user using a toast or any other UI component.
      } else {
        console.log('Failed to create task:', response.status);
        // Optionally, you can show an error message to the user using a toast or any other UI component.
      }
    } catch (error) {
      console.error('Error occurred while creating task:', error);
      // Optionally, you can show an error message to the user using a toast or any other UI component.
    } finally {
      handleModalClose(); // Close the modal regardless of the outcome (success or error)
    }
  };

  const renderTaskCards = (status) => {
    const filteredTasks = tasks.filter((task) => task.TaskStatus === status);

    if (filteredTasks.length === 0) {
      return <Typography variant="body1">No tasks available.</Typography>;
    }

    return filteredTasks.map((task) => {
      if (!task.TaskStatus || !task.TaskName || !task.TaskId || !task.TaskDescription) {
        return null; // Skip invalid tasks
      }

      return (
        <Card key={task.TaskId} sx={{ mb: 2 }}>
          <CardContent>
            <Typography variant="h6">{task.TaskName}</Typography>
            <Typography variant="body2" color="textSecondary">
              {task.TaskDescription}
            </Typography>
            <Button
              variant="outlined"
              color="primary"
              onClick={(e) => handleUpdateButtonClick(e, task.TaskId)}
              sx={{ mr: 1, mt: 1 }}
            >
              Update
            </Button>
            {renderUpdateMenu(task.TaskId, task.TaskStatus)}
          </CardContent>
        </Card>
      );
    });
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <Navbar sx={{ position: 'fixed', top: 0 }} />
      <Container sx={{ flex: 1, paddingTop: '64px', paddingBottom: '64px' }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Task Page
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="h5">To Do</Typography>
            {renderTaskCards('To do')}
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="h5">In Progress</Typography>
            {renderTaskCards('In Progress')}
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="h5">In Review</Typography>
            {renderTaskCards('In Review')}
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <Typography variant="h5">Done</Typography>
            {renderTaskCards('Done')}
          </Grid>
        </Grid>
        <Button variant="contained" color="primary" onClick={handleModalOpen}>
          Create Task
        </Button>
      </Container>
      <Footer sx={{ position: 'fixed', bottom: 0 }} />
      {/* Modal */}
      <Dialog open={openModal} onClose={handleModalClose}>
        <DialogTitle>Create Task</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="Project ID"
            name="project_id"
            value={modalData.project_id}
            onChange={handleModalInputChange}
            margin="dense"
          />
          <TextField
            fullWidth
            label="Task Name"
            name="task_name"
            value={modalData.task_name}
            onChange={handleModalInputChange}
            margin="dense"
          />
          <TextField
            fullWidth
            label="Task Description"
            name="task_description"
            value={modalData.task_description}
            onChange={handleModalInputChange}
            margin="dense"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleModalClose}>Cancel</Button>
          <Button onClick={handleCreateTask} color="primary">
            Create
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default TaskPage;

