import React, { useState } from 'react';
import { Button, Container, TextField, Typography } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';

function SignUp() {
  const [email, setEmail] = useState('');
  const [employeeId, setEmployeeId] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const SignupEndpoint=`${process.env.REACT_APP_API_ENDPOINT}/signup`
  console.log(SignupEndpoint)

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Employee ID validation
    if (employeeId.length !== 9 || !/^[A-Za-z]{3}\d{6}$/.test(employeeId)) {
      alert('Employee ID must be 3 letters followed by 6 digits.');
      return;
    }

    // Password validation
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordRegex.test(password)) {
      alert(
        'Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character (@ $ ! % * ? &).'
      );
      return;
    }

    if (password !== confirmPassword) {
      alert('Passwords do not match.');
      return;
    }

    // Prepare the data object to be sent in the request body
    const formData = {
      email,
      employee_id: employeeId,
      password,
      confirm_password: confirmPassword,
    };

    try {
      // Make the POST request to the backend API
      const response = await fetch(SignupEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
        mode: 'cors',
      });

      // Check the response status to handle success or error
      if (response.ok) {
        // If the response is successful, navigate to the login page
        navigate('/login');
      } else {
        // If there was an error in the API, show an appropriate message
        const errorData = await response.json();
        alert(errorData.message); // Assuming the backend sends an error message in the response body
      }
    } catch (error) {
      // Handle any other errors that may occur during the fetch
      console.error('Error occurred:', error);
      alert('An error occurred while processing your request.');
    }
  };

  return (
    <Container maxWidth="sm">
      <Typography variant="h4" component="h1" gutterBottom>
        Sign Up
      </Typography>
      <form onSubmit={handleSubmit}>
        <TextField
          label="Email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          fullWidth
          margin="normal"
          required
        />
        <TextField
          label="Employee ID"
          type="text"
          value={employeeId}
          onChange={(e) => setEmployeeId(e.target.value)}
          fullWidth
          margin="normal"
          required
        />
        <TextField
          label="Password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          fullWidth
          margin="normal"
          required
        />
        <TextField
          label="Confirm Password"
          type="password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          fullWidth
          margin="normal"
          required
        />
        <Button variant="contained" color="primary" type="submit">
          Sign Up
        </Button>
        <Typography variant="body2" gutterBottom>
          Already have an account? <Link to="/login">Login</Link>
        </Typography>
      </form>
    </Container>
  );
}

export default SignUp;
