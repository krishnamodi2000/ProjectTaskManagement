import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Container, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button, TextField } from '@mui/material';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

function UserDashboard() {
  const { emailOrEmployeeId } = useParams();
  const [userData, setUserData] = useState(null);
  const navigateToTask = useNavigate();
  const DashboardEndpoint=`${process.env.REACT_APP_API_ENDPOINT}/dashboard`
  console.log(DashboardEndpoint)
  const ProcessRequestEndpoint=`${process.env.REACT_APP_API_ENDPOINT}/proccessrequest`
  console.log(ProcessRequestEndpoint)

  useEffect(() => {
    if (emailOrEmployeeId) {
 
      // Function to fetch user data from the backend
      const fetchUserData = async () => {
        try {
          const response = await fetch(DashboardEndpoint, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              email_or_employee_id: emailOrEmployeeId,
            }),
          });

          if (response.ok) {
            const responseData = await response.json();
            // const userDataFromResponse = responseData.body;
            setUserData(responseData); 
          } else {
            console.log('Failed to fetch user data:', response.status);
          }
        } catch (error) {
          console.error('Error occurred while fetching user data:', error);
        }
      };

      fetchUserData();
    }
  }, [emailOrEmployeeId]); // Call the function when the user ID changes (when the component mounts and when the user ID is updated)

       //trigger lambda function

  const handleUpdateProjectsList = async () => {
        try {
          const response = await fetch(ProcessRequestEndpoint, {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
            },
          });
    
          if (response.ok) {
            const responseData = await response.json();
            console.log(responseData.body); // Log the response body
            // Optionally, you can update the state or show a success message to the user.
          } else {
            console.log('Failed to trigger Lambda function:', response.status);
          }
        } catch (error) {
          console.error('Error occurred while triggering Lambda function:', error);
        }
      };
  return (
    <>
      <Navbar emailOrEmployeeId={emailOrEmployeeId} sx={{ position: 'fixed', top: 0 }} />
      <div style={{ paddingTop: '64px', paddingBottom: '64px' }}>
        <Container maxWidth="sm">
          <Typography variant="h4" component="h1" gutterBottom>
            User Dashboard
          </Typography>
          {userData && (
            <>
              <Typography variant="h6" gutterBottom>
                Employee ID :
              </Typography>
              <TextField
                value={userData.EmployeeId}
                InputProps={{
                  readOnly: true,
                }}
                fullWidth
                margin="normal"
              />
              <Typography variant="h6" gutterBottom>
                Email:
              </Typography>
              <TextField
                value={userData.Email}
                InputProps={{
                  readOnly: true,
                }}
                fullWidth
                margin="normal"
              />
              <Typography variant="h6" gutterBottom>
                Projects:
              </Typography>
              {userData.Projects && userData.Projects.length > 0 ? (
                <TableContainer component={Paper}>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>Project Name</TableCell>
                        <TableCell align="right">Actions</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {userData.Projects.map((project) => (
                        <TableRow key={project}>
                          <TableCell>{project}</TableCell>
                          <TableCell align="right">
                            <Button variant="contained" color="primary" onClick={() => navigateToTask(`/tasks/${project}`)}>
                              View Tasks
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              ) : (
                <Typography variant="body1">No projects to show.</Typography>
              )}
            </>
          )}
        <Button variant="contained" color="primary" onClick={handleUpdateProjectsList}>
        Update Projects List
        </Button>
        </Container>
      </div>
      <Footer sx={{ position: 'fixed', bottom: 0 }} />
    </>
  );
}

export default UserDashboard;
