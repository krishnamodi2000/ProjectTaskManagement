import React, { useState, useEffect } from 'react';
import { Container, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField } from '@mui/material';
import Footer from '../components/Footer';
import Navbar from '../components/Navbar';

function ProjectDashboard() {
  const [openModal, setOpenModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [requestData, setRequestData] = useState({ email: '' });
  const [errors, setErrors] = useState({ email: '' });
  const [projectsData, setProjectsData] = useState([]);
  const ProjectsEndpoint=`${process.env.REACT_APP_API_ENDPOINT}/projects`
  console.log(ProjectsEndpoint)
  const AccessRequestEndpoint=`${process.env.REACT_APP_API_ENDPOINT}/accessrequest`
  console.log(AccessRequestEndpoint)

  const availableProjects = projectsData.map((project) => ({ id: project.project_id, name: project.project_name }));

  useEffect(() => {
    // Fetch project data from the backend
    const fetchProjectsData = async () => {
      try {
        const response = await fetch(ProjectsEndpoint);
        if (response.ok) {
          const responseData = await response.json();
          setProjectsData(responseData);
        } else {
          console.log('Failed to fetch projects data:', response.status);
        }
      } catch (error) {
        console.error('Error occurred while fetching projects data:', error);
      }
    };

    fetchProjectsData();
  }, []);

  const handleOpenModal = (projectId) => {
    const project = projectsData.find((p) => p.project_id === projectId);
    setSelectedProject(project);
    setOpenModal(true);
    setErrors({ email: '' });
  };

  const handleCloseModal = () => {
    setOpenModal(false);
    setSelectedProject(null);
    setRequestData({ email: '' });
    setErrors({ email: '' });
  };

  const validateForm = () => {
    let isValid = true;
    const errorsCopy = { ...errors };

    if (!/^[\w.-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(requestData.email)) {
      errorsCopy.email = 'Invalid email format.';
      isValid = false;
    } else {
      errorsCopy.email = '';
    }

    setErrors(errorsCopy);
    return isValid;
  };

  const handleRequestAccess = async () => {
    if (validateForm()) {
      try {
        const response = await fetch(AccessRequestEndpoint, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email: requestData.email,
            project_id: selectedProject.project_id,
          }),
        });

        console.log(requestData.email)
        console.log(selectedProject.project_id)

        if (response.ok) {
          const responseData = await response.json();
          console.log(responseData.body);
          handleCloseModal();
        } else {
          console.log('Failed to send access request:', response.status);
        }
      } catch (error) {
        console.error('Error occurred while sending access request:', error);
      }
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <Navbar sx={{ position: 'fixed', top: 0 }} />
      <Container sx={{ flex: 1, paddingTop: '64px', paddingBottom: '64px' }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Project Dashboard
        </Typography>
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Project Name</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {availableProjects.map((project) => (
                <TableRow key={project.id}>
                  <TableCell>{project.name}</TableCell>
                  <TableCell align="right">
                    <Button variant="contained" color="primary" onClick={() => handleOpenModal(project.id)}>
                      Request Access
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {/* Request Access Modal */}
        <Dialog open={openModal} onClose={handleCloseModal}>
          <DialogTitle>Request Access for {selectedProject?.project_name}</DialogTitle>
          <DialogContent>
            <TextField
              label="Email"
              type="email"
              value={requestData.email}
              onChange={(e) => setRequestData({ ...requestData, email: e.target.value })}
              fullWidth
              margin="normal"
              required
              error={Boolean(errors.email)}
              helperText={errors.email}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleRequestAccess} variant="contained" color="primary">
              Submit Request
            </Button>
            <Button onClick={handleCloseModal} variant="outlined" color="primary">
              Cancel
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
      <Footer sx={{ position: 'fixed', bottom: 0 }} />
    </div>
  );
}

export default ProjectDashboard;
