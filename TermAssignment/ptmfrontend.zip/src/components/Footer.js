import React from 'react';
import { AppBar, Toolbar, Typography } from '@mui/material';

function Footer() {
  return (
    <AppBar position="static" sx={{ top: 'auto', bottom: 0 }}>
      <Toolbar>
        <Typography variant="body2" color="inherit" sx={{ flexGrow: 1, textAlign: 'center' }}>
          © {new Date().getFullYear()} ProjectTaskManagement. Made by Krishna Modi. Cloud Term Assignment Summer 2023
        </Typography>
      </Toolbar>
    </AppBar>
  );
}

export default Footer;
