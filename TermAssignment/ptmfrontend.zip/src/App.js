import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import SignUp from './pages/Signup';
import Login from './pages/Login';
import UserDashboard from './pages/UserDashboard';
import ProjectDashboard from './pages/ProjectDashboard';
import TaskPage from './pages/TaskPage';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<SignUp />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard/:emailOrEmployeeId" element={<UserDashboard />} />
        <Route path = "/projects" element= {<ProjectDashboard/>} />
        <Route path ="/tasks/:project" element={<TaskPage/>}/>
      </Routes>
    </Router>
  );
}

export default App;
